//-----------------------------------------------------------------------
// <copyright file="ClassA1.cs" company="MSBuild Community Tasks Project">
//     Copyright � 2006 Ignaz Kohlbecker
// </copyright>
//-----------------------------------------------------------------------


namespace MSBuild.Community.Tasks.Tests.ILMerging
{
	/// <summary>
	/// Public test class for ILMerge.
	/// </summary>
	public class ClassA1
	{
	}
}
