//-----------------------------------------------------------------------
// <copyright file="ClassA2.cs" company="MSBuild Community Tasks Project">
//     Copyright � 2006 Ignaz Kohlbecker
// </copyright>
//-----------------------------------------------------------------------


namespace MSBuild.Community.Tasks.Tests.ILMerging
{
	/// <summary>
	/// Internal test class for ILMerge.
	/// </summary>
	internal class ClassA2
	{
	}
}
