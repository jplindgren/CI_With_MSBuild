﻿#region Copyright © 2008 MSBuild Community Task Project. All rights reserved.
/*
Copyright © 2008 MSBuild Community Task Project. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#endregion

using System;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;



namespace MSBuild.Community.Tasks.Fusion
{
    [ComImport]
    [Guid("e707dcde-d1cd-11d2-bab9-00c04f8eceae")]
    [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    internal interface IAssemblyCache
    {
        [PreserveSig]
        [return: MarshalAs(UnmanagedType.Error)]
        int UninstallAssembly(
            int flags,
            [MarshalAs(UnmanagedType.LPWStr)] string assemblyName,
            [MarshalAs(UnmanagedType.LPArray)] InstallReference[] references,
            [MarshalAs(UnmanagedType.U4)] out UninstallStatus disposition);

        [PreserveSig]
        [return: MarshalAs(UnmanagedType.Error)]
        int QueryAssemblyInfo(
            int flags,
            [MarshalAs(UnmanagedType.LPWStr)] string assemblyName,
            ref AssemblyInfo assemblyInfo);

        [PreserveSig]
        [return: MarshalAs(UnmanagedType.Error)]
        int CreateAssemblyCacheItem(
            int flags,
            IntPtr reserved,
            out IAssemblyCacheItem assemblyCacheItem,
            [MarshalAs(UnmanagedType.LPWStr)] string assemblyName);

        [PreserveSig]
        [return: MarshalAs(UnmanagedType.Error)]
        int CreateAssemblyScavenger(
            [MarshalAs(UnmanagedType.IUnknown)] out object assemblyScavenger);

        [PreserveSig]
        [return: MarshalAs(UnmanagedType.Error)]
        int InstallAssembly(
            int flags,
            [MarshalAs(UnmanagedType.LPWStr)] string manifestFilePath,
            [MarshalAs(UnmanagedType.LPArray)] InstallReference[] references);
    }
}
